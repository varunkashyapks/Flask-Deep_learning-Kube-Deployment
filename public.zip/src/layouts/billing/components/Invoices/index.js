

// @mui material components
import Card from "@mui/material/Card";
import Grid from "@mui/material/Grid";
//  React components
import MDBox from "components/MDBox";
import MDTypography from "components/MDTypography";
import MDButton from "components/MDButton";

// Billing page components
import Invoice from "layouts/billing/components/Invoice";
import React, { useState, useEffect } from 'react';
import Tooltip from '@mui/material/Tooltip';

import { DataGrid, GridToolbar,GridToolbarExport  } from '@mui/x-data-grid';

function Invoices() {
  const [apiData, setApiData] = useState({});
  const [selectedName, setSelectedName] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('http://127.0.0.1:5000/api/skl');
        const data = await response.json();

        if (typeof data === 'object' && !Array.isArray(data)) {
          setApiData(data);
          setSelectedName(Object.keys(data)[0]);
        } else {
          console.error('API response is not in the expected format:', data);
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  const handleNameChange = (event) => {
    setSelectedName(event.target.value);
  };

  const selectedData = apiData[selectedName]?.expertise || [];

  const filteredRows = selectedData.map((expertise, index) => ({
    id: index + 1,
    rankName: expertise.rankname,
    rank: expertise.rank,
    role: expertise.role,
  }));

  const filteredColumns = [
    { field: 'rankName', headerName: 'Rank Name', width: 150 },
    { field: 'rank', headerName: 'Rank', width: 150 ,cellClassName: 'rankCell' },
    { field: 'role', headerName: 'Role', width: 150 },
  ];
  const styles = `
  .tooltip {
    cursor: pointer;
    text-decoration: underline;
    color: red;
    }
  `;
  const rankDescriptions = {
    l1: 'Novice',
    l2: 'Beginner',
    // Add more as needed
  };
  return (
    <Card sx={{ height: "92%" }}>
<MDBox pt={3} pb={2}>
  <Grid container spacing={2}>
    <Grid item xs={12}>
      <Card>
        <MDBox
          mx={1}
          mt={-3}
          py={3}
          px={2}
          variant="gradient"
          bgColor="info"
          borderRadius="lg"
          coloredShadow="info"
        >
          <MDTypography variant="h6" color="white"style={{ textAlign: 'center' }}>
          sklltab Table
          </MDTypography>
        </MDBox>
        <MDBox pt={4}>
          {/* Add Tooltip to the "Select Name" label */}
          <Tooltip title="Select a name" arrow>
              <label
              htmlFor="nameFilter"
                  style={{
                    fontSize: '14px',
                    fontWeight: 'bold',
                    color: 'black',
                    marginBottom: '8px',
                  }}>Select a Name:</label>
                <select id="names" value={selectedName} onChange={handleNameChange}>
                  {Object.keys(apiData).map((name, index) => (
                    <option key={index} value={name}>{name}</option>
                  ))}
                </select>
              </Tooltip>

          {/* Add Tooltip to the "Rank" column in the DataGrid */}
          <div style={{ height: 400, width: '100%' }}>
            <DataGrid
              rows={filteredRows}
              columns={filteredColumns.map((column) => {
                if (column.field === 'rank') {
                  return {
                    ...column,
                    renderCell: (params) => (
                      <Tooltip title={`${params.value} - ${rankDescriptions[params.value]}`} arrow>
                        <span className="tooltip">{params.value}</span>
                      </Tooltip>
                    ),
                  };
                }

                return column;
              })}
              pageSize={5}
              checkboxSelection
              disableSelectionOnClick
              components={{
                Toolbar: GridToolbar,
              }}
              componentsProps={{
                toolbar: {
                  exportButton: <GridToolbarExport />,
                },
              }}
            />
          </div>
        </MDBox>
      </Card>
    </Grid>
  </Grid>
</MDBox>
    </Card>
  );
}

export default Invoices;
