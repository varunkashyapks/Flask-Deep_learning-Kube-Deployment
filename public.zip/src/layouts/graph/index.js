

// @mui material components
import Grid from "@mui/material/Grid";
import Card from "@mui/material/Card";

//  React components
import MDBox from "components/MDBox";
import MDTypography from "components/MDTypography";

//  React example components
import DashboardLayout from "examples/LayoutContainers/DashboardLayout";
import DashboardNavbar from "examples/Navbars/DashboardNavbar";
// import Footer from "examples/Footer";
import DataTable from "examples/Tables/DataTable";

// Data
import authorsTableData from "layouts/graph/data/authorsTableData";
// import projectsTableData from "layouts/tables/data/projectsTableData";
import React from 'react';
import Plot from 'react-plotly.js';


function Graph() {
  // Assuming you have some sample data for the plot
  const plotData = [
    {
      x: [1, 2, 3, 4, 5],
      y: [10, 11, 12, 13, 14],
      type: 'scatter',
      mode: 'lines+markers',
      marker: { color: 'red' },
    },
  ];

  const { columns, rows } = authorsTableData();

  return (
    <DashboardLayout>
      <DashboardNavbar />
      <MDBox pt={6} pb={3}>
        <Grid container spacing={6}>
          <Grid item xs={12}>
            <Card>
              <MDBox
                mx={2}
                mt={-3}
                py={3}
                px={2}
                variant="gradient"
                bgColor="info"
                borderRadius="lg"
                coloredShadow="info"
              >
                <MDTypography variant="h6" color="white">
                  Authors Table
                </MDTypography>
              </MDBox>
              <Grid item xs={12}>
            <Card>
              <MDBox p={3}>
                <MDTypography variant="h6">Sample Plotly Graph</MDTypography>
                <Plot data={plotData} layout={{ width: 900, height: 600 }} />
              </MDBox>
            </Card>
          </Grid>
            </Card>
          </Grid>

        </Grid>
      </MDBox>
      {/* <Footer /> */}
    </DashboardLayout>
  );
}

export default Graph;