

// prop-types is a library for typechecking of props
import PropTypes from "prop-types";

// @mui material components
import Icon from "@mui/material/Icon";
import { useEffect, useState } from 'react';
//  React components
import MDBox from "components/MDBox";
import MDTypography from "components/MDTypography";

function Invoice({ date, id, price, noGutter, userId }) {
  const [csvData, setCsvData] = useState('');

  useEffect(() => {
    // Load the corresponding CSV file based on userId
    const csvFilePath = `/path/to/csv/user-${userId}.csv`;

    // Fetch the CSV file
    fetch(csvFilePath)
      .then(response => response.text())
      .then(data => {
        // Create a CSV string with the provided data
        setCsvData(data);
      })
      .catch(error => {
        console.error('Error fetching CSV file:', error);
      });
  }, [userId]);

  const downloadCSV = () => {
    const blob = new Blob([csvData], { type: 'text/csv' });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = `user-${userId}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <MDBox
      component="li"
      display="flex"
      justifyContent="space-between"
      alignItems="center"
      py={1}
      pr={1}
      mb={1}
    >
      <MDBox lineHeight={1.125}>
        <MDTypography display="block" variant="button" fontWeight="medium">
          {date}
        </MDTypography>
        <MDTypography variant="caption" fontWeight="regular" color="text">
          {id}
        </MDTypography>
      </MDBox>
      <MDBox display="flex" alignItems="center">
        <MDTypography variant="button" fontWeight="regular" color="text">
          {price}
        </MDTypography>
        <MDBox
          display="flex"
          alignItems="center"
          lineHeight={1}
          ml={3}
          sx={{ cursor: 'pointer' }}
          onClick={downloadCSV}
        >
          <Icon fontSize="small">insert_drive_file</Icon>
          <MDTypography variant="button" fontWeight="bold">
            &nbsp;Download CSV
          </MDTypography>
        </MDBox>
      </MDBox>
    </MDBox>
  );
}

// Setting default values for the props of Invoice
Invoice.defaultProps = {
  noGutter: false,
};

// Typechecking props for the Invoice
Invoice.propTypes = {
  date: PropTypes.string.isRequired,
  id: PropTypes.string.isRequired,
  price: PropTypes.string.isRequired,
  noGutter: PropTypes.bool,
};

export default Invoice;
