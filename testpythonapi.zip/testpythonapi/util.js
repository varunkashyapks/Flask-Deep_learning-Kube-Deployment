

// @mui material components
import Grid from "@mui/material/Grid";
import Card from "@mui/material/Card";

//  React components
import MDBox from "components/MDBox";
import MDTypography from "components/MDTypography";

//  React example components
import DashboardLayout from "examples/LayoutContainers/DashboardLayout";
import DashboardNavbar from "examples/Navbars/DashboardNavbar";
// import Footer from "examples/Footer";
import DataTable from "examples/Tables/DataTable";

// Data
import authorsTableData from "layouts/settab/data/authorsTableData";

import React, { useState, useEffect } from 'react';
import { Bar } from 'react-chartjs-2';

import Plot from 'react-plotly.js';

import { DataGrid, GridToolbar } from '@mui/x-data-grid';
// import { useDemoData } from '@mui/x-data-grid-generator';

import { MenuItem, Select, FormControl, InputLabel } from '@mui/material';
const VISIBLE_FIELDS = ['endDate', 'startDate'];



function Settab() {
  const [columns, setColumns] = useState([]);
  const [rows, setRows] = useState([]);
  const [selectedMD, setSelectedMD] = useState('');
  const [selectedMonthYear, setselectedMonthYear] = useState('');
  const [selectedMonth2, setSelectedMonth2] = useState('');
  const [chartDataByAuthor, setChartDataByAuthor] = useState([]);
  const [chartDataByMonth, setChartDataByMonth] = useState({});
  const [selectedProjectName, setSelectedProjectName] = useState('');
  const [selectedProjectName2, setSelectedProjectName2] = useState('');
  const [selectedName, setSelectedName] = useState('');
  const [barGraph, setBarGraph] = useState([]);
  const [barGraph2, setBarGraph2] = useState([]); // Separate state variable for graph 2
  const filteredColumns = columns.filter(column => column.field !== 'id');
  useEffect(() => {
    const fetchAuthorsData = async () => {
      try {
        const response = await fetch('http://127.0.0.1:5000/api/authors');
        const data = await response.json();
        

        // Modify the data format to ensure compatibility with the graph component
        const formattedData = data.map(row => ({
          ...row,
          StartDate: parseDate(row.StartDate),
          EndDate: parseDate(row.EndDate),
          MonthYear: row.MonthYear // Assuming MonthYear is in the format "MMM-YYYY"
        }));

        setRows(formattedData);

        // Extract columns from the first row
        if (formattedData.length > 0) {
          const firstRow = formattedData[0];
          const columns = Object.keys(firstRow).map(key => {
            let width = 100; // Default width
            // Adjust width based on column key or other conditions if needed
            if (key === 'ProjectName' || key === 'Department') {
              width = 130; // Custom width for the 'Author' and 'Department' columns
            } else if (key === 'StartDate' || key === 'EndDate') {
              width = 160; // Custom width for date columns
            }
            return {
              field: key,
              headerName: key.charAt(0).toUpperCase() + key.slice(1),
              width: width,
            };
          });
          setColumns(columns);
        }
      } catch (error) {
        console.error('Error fetching authors data:', error);
      }
    };

    fetchAuthorsData();
  }, []);

  useEffect(() => {
    if (!selectedProjectName || !selectedName) return;
  
    // Filter data by selected ProjectName and Name
    const filteredData = rows.filter(
      row =>
        row.ProjectName === selectedProjectName &&
        row.Name === selectedName
    );
  
    // Extract MonthYear and corresponding Allocation and Utilization data
    const allocationData = filteredData.map(row => ({
      monthYear: row.MonthYear,
      allocation: row.Allocation,
      utilization: row.Utilization
    }));
  
    // Sort data by MonthYear
    allocationData.sort((a, b) => a.monthYear.localeCompare(b.monthYear));
  
    // Extract MonthYear, Allocation, and Utilization for plotting
    const months = allocationData.map(entry => entry.monthYear);
    const allocations = allocationData.map(entry => entry.allocation);
    const utilizations = allocationData.map(entry => entry.utilization);
  
    // Create the bar graph data
    const graphData = [
      {
        x: months,
        y: allocations,
        type: 'bar',
        name: 'Allocation'
      },
      {
        x: months,
        y: utilizations,
        type: 'bar',
        name: 'Utilization'
      }
    ];
  
    setBarGraph(graphData);
  }, [selectedProjectName, selectedName, rows]);
  

  useEffect(() => {
    if (!selectedProjectName2 || !selectedMonth2) return;
  
    // Filter data by selected project name and month year
    const filteredData = rows.filter(row => {
      return row.ProjectName === selectedProjectName2 && row.MonthYear === selectedMonth2;
    });
  
    // Calculate total utilization for each name
    const nameUtilizationMap = {};
    filteredData.forEach(row => {
      const name = row.Name;
      const utilization = parseFloat(row.Utilization);
      if (nameUtilizationMap[name]) {
        nameUtilizationMap[name] += utilization;
      } else {
        nameUtilizationMap[name] = utilization;
      }
    });
  
    // Prepare data for the bar graph
    const chartData = {
      x: Object.keys(nameUtilizationMap),
      y: Object.values(nameUtilizationMap),
      type: 'bar',
      marker: {
        color: 'rgb(75,192,192)',
      },
    };
  
    setBarGraph2([chartData]);
  }, [selectedProjectName2, selectedMonth2, rows]);
  

  const parseDate = dateString => {
    const [day, month, year] = dateString.split('-');
    return new Date(year, month - 1, day);
  };

  return (
    <DashboardLayout>
      <DashboardNavbar />
      <MDBox pt={6} pb={3}>
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Card>
              <MDBox mx={2} mt={-3} py={3} px={2} variant="gradient" bgColor="info" borderRadius="lg" coloredShadow="info">
                <MDTypography variant="h6" color="white">
                  Authors Table
                </MDTypography>
              </MDBox>
              <MDBox pt={3}>
                <div style={{ height: 500, width: '100%' }}>
                  <DataGrid
                    rows={rows}
                    checkboxSelection
                    columns={filteredColumns.map(column => ({
                      ...column,
                      hide: !VISIBLE_FIELDS.includes(column.field),
                    }))}
                    pageSize={5}
                    pagination
                    components={{
                      Toolbar: GridToolbar,
                    }}
                  />
                </div>
              </MDBox>
            </Card>
          </Grid>
          <Grid item xs={12} md={6}>
      <Card>
        <MDBox mx={2} mt={-3} py={2} px={2} variant="gradient" bgColor="info" borderRadius="lg" coloredShadow="info">
          <MDTypography variant="subtitle1" color="white" mb={1}>
            Allocation and Utilization Comparison by Month
          </MDTypography>
          <Grid container spacing={1} sx={{ backgroundColor: 'white', borderRadius: '4px', padding: '8px' }}>
            <Grid item xs={6} sm={3} md={6} lg={3}>
              <FormControl fullWidth size="small">
                <InputLabel id="project-name-filter-label" style={{ fontSize: '0.75rem', color: 'white' }}>ProjectName</InputLabel>
                <Select
                  labelId="project-name-filter-label"
                  id="project-name-filter"
                  value={selectedProjectName}
                  onChange={event => setSelectedProjectName(event.target.value)}
                  sx={{ color: 'white' }}
                  style={{ minWidth: '8ch' }}
                >
                  <MenuItem value=""></MenuItem>
                  {[...new Set(rows.map(row => row.ProjectName))].map(projectName => (
                    <MenuItem key={projectName} value={projectName}>{projectName}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={6} sm={3} md={6} lg={3}>
              <FormControl fullWidth size="small">
                <InputLabel id="name-filter-label" style={{ fontSize: '0.75rem', color: 'white' }}>Name</InputLabel>
                <Select
                  labelId="name-filter-label"
                  id="name-filter"
                  value={selectedName}
                  onChange={event => setSelectedName(event.target.value)}
                  sx={{ color: 'white' }}
                  style={{ minWidth: '8ch' }}
                >
                  <MenuItem value=""></MenuItem>
                  {[...new Set(rows.map(row => row.Name))].map(name => (
                    <MenuItem key={name} value={name}>{name}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        </MDBox>
        <MDBox pt={1} pb={1}>
          <Plot
            data={barGraph}
            layout={{ barmode: 'group', title: `Allocation and Utilization Comparison by Month for ${selectedProjectName}`, responsive: true }}
            style={{ width: '100%' }}
            config={{ responsive: true }}
          />
        </MDBox>
      </Card>
    </Grid>
    <Grid item xs={12} md={6}>
  <Card>
    <MDBox mx={2} mt={-3} py={3} px={2} variant="gradient" bgColor="info" borderRadius="lg" coloredShadow="info">
      <MDTypography variant="h6" color="white">Utilization Comparison by Name</MDTypography>
      <Grid container spacing={1} sx={{ backgroundColor: 'white', borderRadius: '4px', padding: '8px' }}>
        <Grid item xs={6} sm={3} md={6} lg={3}>
          <FormControl fullWidth size="small">
            <InputLabel id="project-filter-label" style={{ fontSize: '0.75rem', color: 'white' }}>ProjectName</InputLabel>
            <Select
              labelId="project-filter-label"
              id="project-filter"
              value={selectedProjectName2}
              onChange={event => setSelectedProjectName2(event.target.value)}
              sx={{ color: 'white' }}
              style={{ minWidth: '8ch' }} // Adjust the width here
            >
              <MenuItem value="">All</MenuItem>
              {[...new Set(rows.map(row => row.ProjectName))].map(project => (
                <MenuItem key={project} value={project}>{project}</MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={6} sm={3} md={6} lg={3}>
          <FormControl fullWidth size="small">
            <InputLabel id="month-filter-label-2" style={{ fontSize: '0.75rem', color: 'white' }}>MonthYear</InputLabel>
            <Select
              labelId="month-filter-label-2"
              id="month-filter-2"
              value={selectedMonth2}
              onChange={event => setSelectedMonth2(event.target.value)}
              sx={{ color: 'white' }}
              style={{ minWidth: '8ch' }} // Adjust the width here
            >
              <MenuItem value="">All</MenuItem>
              {[...new Set(rows.map(row => row.MonthYear))].map(monthYear => (
                <MenuItem key={monthYear} value={monthYear}>{monthYear}</MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>
      </Grid>
    </MDBox>
    <MDBox pt={3}>
      <Plot
        data={barGraph2}
        layout={{ title: `Utilization Comparison by Name for ${selectedProjectName2} (${selectedMonth2})`, barmode: 'group', responsive: true }}
        style={{ width: '100%' }}
        config={{ responsive: true }}
      />
    </MDBox>
  </Card>
</Grid>

        </Grid>
      </MDBox>
    </DashboardLayout>
  );
}




export default Settab;
