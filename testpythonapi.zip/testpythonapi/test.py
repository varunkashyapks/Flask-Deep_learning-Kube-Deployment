from flask import Flask, jsonify, request
from flask_cors import CORS  # Import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes
# Simulated user data (for demonstration purposes)
users = {
    'user1': {'password': 'qwer'},
    'user2': {'password': 'qwer'},
}

@app.route('/api/signin', methods=['POST'])
def signin():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')

    if email in users and users[email]['password'] == password:
        # Authentication successful, return a token or user information
        return jsonify({'message': 'Authentication successful'}), 200
    else:
        # Authentication failed, return 401 Unauthorized
        return jsonify({'message': 'Authentication failed'}), 401

@app.route('/api/skl', methods=['GET'])
def skl():
    data = {
        'name1':{
            'dep': 'depA',
            'expertise':[
                {
                    'rankname':'py',
                    'rank':'l1',
                    'role': 'ss'

                },
                {
                    'rankname':'pdsdsy',
                    'rank':'l1',
                    'role': 'ss'

                }
            ]
        },
        'name2':{
            'dep': 'depB',
            'expertise':[
                {
                    'rankname':'sdd',
                    'rank':'l1',
                    'role': 'ss'

                }
            ]
        }
    }
    return jsonify(data)

@app.route('/api/rbac', methods=['POST'])
def handle_post_request():
    try:
        data = request.json
        username = data.get('email')
        # Here you can process the username as needed
        allowed_pages = []
        if username=='user1':
        # Assuming you have some RBAC logic here
        # For demonstration purposes, let's pretend allowedPages are retrieved from some database
            allowed_pages = ["graph", "profile","sign-in", "sign-up","dashboard"]
        elif username=='user2':
            allowed_pages = ["settab", "profile","sign-in", "sign-up","dashboard"]
        else:
            allowed_pages = ["settab", "profile","sign-in", "sign-up","allocation","dashboard"]
        return jsonify({'allowedPages': allowed_pages}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500
@app.route('/api/authors')
def get_authors():
    # Dummy data
    authors = [
    {
        "id": 1,
        "StartDate": "01-04-2023",
        "EndDate": "30-04-2023",
        "PId": "1001",
        "Name": "Ran A",
        "Department": "Admin",
        "ProjectName": "Wow Proj A",
        "Allocation": "50%",
        "Utilization": "98%",
        "MonthYear": "Apr-23"
    },
    {
        "id": 2,
        "StartDate": "01-05-2023",
        "EndDate": "31-05-2023",
        "PId": "1001",
        "Name": "Ran A",
        "Department": "Admin",
        "ProjectName": "Wow Proj A",
        "Allocation": "50%",
        "Utilization": "98%",
        "MonthYear": "May-23"
    },
    {
        "id": 3,
        "StartDate": "21-04-2023",
        "EndDate": "30-04-2023",
        "PId": "1002",
        "Name": "Ban B",
        "Department": "UX",
        "ProjectName": "Wow Proj D",
        "Allocation": "70%",
        "Utilization": "78%",
        "MonthYear": "Apr-23"
    },
    {
        "id": 4,
        "StartDate": "01-05-2023",
        "EndDate": "31-05-2023",
        "PId": "1002",
        "Name": "Ban B",
        "Department": "UX",
        "ProjectName": "Wow Proj D",
        "Allocation": "70%",
        "Utilization": "78%",
        "MonthYear": "May-23"
    },
    {
        "id": 5,
        "StartDate": "01-01-2023",
        "EndDate": "31-01-2023",
        "PId": "1003",
        "Name": "Rum D",
        "Department": "Admin",
        "ProjectName": "Wow Proj A",
        "Allocation": "50%",
        "Utilization": "58%",
        "MonthYear": "Jan-23"
    },
    {
        "id": 6,
        "StartDate": "01-02-2023",
        "EndDate": "28-02-2023",
        "PId": "1003",
        "Name": "Rum D",
        "Department": "Admin",
        "ProjectName": "Wow Proj A",
        "Allocation": "50%",
        "Utilization": "58%",
        "MonthYear": "Feb-23"
    },
    {
        "id": 7,
        "StartDate": "01-03-2023",
        "EndDate": "31-03-2023",
        "PId": "1003",
        "Name": "Rum D",
        "Department": "Admin",
        "ProjectName": "Wow Proj A",
        "Allocation": "50%",
        "Utilization": "58%",
        "MonthYear": "Mar-23"
    },
    {
        "id": 8,
        "StartDate": "01-04-2023",
        "EndDate": "30-04-2023",
        "PId": "1003",
        "Name": "Rum D",
        "Department": "Admin",
        "ProjectName": "Wow Proj A",
        "Allocation": "50%",
        "Utilization": "58%",
        "MonthYear": "Apr-23"
    },
    {
        "id": 9,
        "StartDate": "11-02-2023",
        "EndDate": "28-02-2023",
        "PId": "1004",
        "Name": "Whishky",
        "Department": "UX",
        "ProjectName": "Wow Proj E",
        "Allocation": "35%",
        "Utilization": "38%",
        "MonthYear": "Feb-23"
    },
    {
        "id": 10,
        "StartDate": "01-03-2023",
        "EndDate": "31-03-2023",
        "PId": "1004",
        "Name": "Whishky",
        "Department": "UX",
        "ProjectName": "Wow Proj E",
        "Allocation": "35%",
        "Utilization": "38%",
        "MonthYear": "Mar-23"
    },
    {
        "id": 11,
        "StartDate": "13-04-2023",
        "EndDate": "30-04-2023",
        "PId": "1005",
        "Name": "GIN",
        "Department": "IT",
        "ProjectName": "Wow Proj B",
        "Allocation": "100%",
        "Utilization": "98%",
        "MonthYear": "Apr-23"
    },
    {
        "id": 12,
        "StartDate": "01-05-2023",
        "EndDate": "31-05-2023",
        "PId": "1005",
        "Name": "GIN",
        "Department": "IT",
        "ProjectName": "Wow Proj B",
        "Allocation": "100%",
        "Utilization": "98%",
        "MonthYear": "May-23"
    },
    {
        "id": 13,
        "StartDate": "01-06-2023",
        "EndDate": "30-06-2023",
        "PId": "1005",
        "Name": "GIN",
        "Department": "IT",
        "ProjectName": "Wow Proj B",
        "Allocation": "100%",
        "Utilization": "98%",
        "MonthYear": "Jun-23"
    },
    {
        "id": 14,
        "StartDate": "01-07-2023",
        "EndDate": "31-07-2023",
        "PId": "1005",
        "Name": "GIN",
        "Department": "IT",
        "ProjectName": "Wow Proj B",
        "Allocation": "100%",
        "Utilization": "98%",
        "MonthYear": "Jul-23"
    },
    {
        "id": 15,
        "StartDate": "01-08-2023",
        "EndDate": "31-08-2023",
        "PId": "1005",
        "Name": "GIN",
        "Department": "IT",
        "ProjectName": "Wow Proj B",
        "Allocation": "100%",
        "Utilization": "98%",
        "MonthYear": "Aug-23"
    },
    {
        "id": 16,
        "StartDate": "01-09-2023",
        "EndDate": "30-09-2023",
        "PId": "1005",
        "Name": "GIN",
        "Department": "IT",
        "ProjectName": "Wow Proj B",
        "Allocation": "100%",
        "Utilization": "98%",
        "MonthYear": "Sep-23"
    },
    {
        "id": 17,
        "StartDate": "01-11-2023",
        "EndDate": "30-11-2023",
        "PId": "1006",
        "Name": "VODKA",
        "Department": "IT",
        "ProjectName": "Wow Proj C",
        "Allocation": "80%",
        "Utilization": "78%",
        "MonthYear": "Nov-23"
    },
    {
        "id": 18,
        "StartDate": "01-12-2023",
        "EndDate": "31-12-2023",
        "PId": "1006",
        "Name": "VODKA",
        "Department": "IT",
        "ProjectName": "Wow Proj C",
        "Allocation": "80%",
        "Utilization": "78%",
        "MonthYear": "Dec-23"
    },
    {
        "id": 19,
        "StartDate": "01-04-2023",
        "EndDate": "30-04-2023",
        "PId": "1007",
        "Name": "Bere",
        "Department": "Admin",
        "ProjectName": "Wow Proj A",
        "Allocation": "20%",
        "Utilization": "58%",
        "MonthYear": "Apr-23"
    },
    {
        "id": 20,
        "StartDate": "01-05-2023",
        "EndDate": "31-05-2023",
        "PId": "1007",
        "Name": "Bere",
        "Department": "Admin",
        "ProjectName": "Wow Proj A",
        "Allocation": "20%",
        "Utilization": "58%",
        "MonthYear": "May-23"
    },
    {
        "id": 21,
        "StartDate": "01-06-2023",
        "EndDate": "30-06-2023",
        "PId": "1007",
        "Name": "Bere",
        "Department": "Admin",
        "ProjectName": "Wow Proj A",
        "Allocation": "20%",
        "Utilization": "58%",
        "MonthYear": "Jun-23"
    },
    {
        "id": 22,
        "StartDate": "01-07-2023",
        "EndDate": "31-07-2023",
        "PId": "1007",
        "Name": "Bere",
        "Department": "Admin",
        "ProjectName": "Wow Proj A",
        "Allocation": "20%",
        "Utilization": "58%",
        "MonthYear": "Jul-23"
    },
    {
        "id": 23,
        "StartDate": "01-08-2023",
        "EndDate": "31-08-2023",
        "PId": "1007",
        "Name": "Bere",
        "Department": "Admin",
        "ProjectName": "Wow Proj A",
        "Allocation": "20%",
        "Utilization": "58%",
        "MonthYear": "Aug-23"
    },
    {
        "id": 24,
        "StartDate": "01-09-2023",
        "EndDate": "30-09-2023",
        "PId": "1007",
        "Name": "Bere",
        "Department": "Admin",
        "ProjectName": "Wow Proj A",
        "Allocation": "20%",
        "Utilization": "58%",
        "MonthYear": "Sep-23"
    }
]
    return jsonify(authors)
if __name__ == '__main__':
    app.run(debug=True)
