

// @mui material components
import Grid from "@mui/material/Grid";
import Card from "@mui/material/Card";

//  React components
import MDBox from "components/MDBox";
import MDTypography from "components/MDTypography";

//  React example components
import DashboardLayout from "examples/LayoutContainers/DashboardLayout";
import DashboardNavbar from "examples/Navbars/DashboardNavbar";
// import Footer from "examples/Footer";
import DataTable from "examples/Tables/DataTable";
import React, { useState, useEffect } from 'react';
import Tooltip from '@mui/material/Tooltip';

import { DataGrid, GridToolbar,GridToolbarExport  } from '@mui/x-data-grid';
// Data
import authorsTableData from "layouts/sklltab/data/authorsTableData";
// import projectsTableData from "layouts/tables/data/projectsTableData";

function SkllTables() {
  const [apiData, setApiData] = useState({});
  const [selectedName, setSelectedName] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('http://127.0.0.1:5000/api/skl');
        const data = await response.json();

        if (typeof data === 'object' && !Array.isArray(data)) {
          setApiData(data);
          setSelectedName(Object.keys(data)[0]);
        } else {
          console.error('API response is not in the expected format:', data);
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  const handleNameChange = (event) => {
    setSelectedName(event.target.value);
  };

  const selectedData = apiData[selectedName]?.expertise || [];

  const filteredRows = selectedData.map((expertise, index) => ({
    id: index + 1,
    rankName: expertise.rankname,
    rank: expertise.rank,
    role: expertise.role,
  }));

  const filteredColumns = [
    { field: 'rankName', headerName: 'Rank Name', width: 450 },
    { field: 'rank', headerName: 'Rank', width: 250 ,cellClassName: 'rankCell' },
    { field: 'role', headerName: 'Role', width: 250 },
  ];
  const styles = `
  .tooltip {
    cursor: pointer;
    text-decoration: underline;
    color: red;
    }
  `;
  const rankDescriptions = {
    l1: 'Novice',
    l2: 'Beginner',
    // Add more as needed
  };
return (
  <DashboardLayout>
    <style>{styles}</style>
    <DashboardNavbar />
    <MDBox pt={6} pb={3}>
      <Grid container spacing={6}>
        <Grid item xs={12}>
          <Card>
            <MDBox
              mx={2}
              mt={-3}
              py={3}
              px={2}
              variant="gradient"
              bgColor="info"
              borderRadius="lg"
              coloredShadow="info"
            >
              <MDTypography variant="h6" color="white">
              sklltab Table
              </MDTypography>
            </MDBox>
            <MDBox pt={4}>
              {/* Add Tooltip to the "Select Name" label */}
              <Tooltip title="Select a name" arrow>
              <label
              htmlFor="nameFilter"
                  style={{
                    fontSize: '14px',
                    fontWeight: 'bold',
                    color: 'black',
                    marginBottom: '8px',
                  }}>Select a Name:</label>
                <select id="names" value={selectedName} onChange={handleNameChange}>
                  {Object.keys(apiData).map((name, index) => (
                    <option key={index} value={name}>{name}</option>
                  ))}
                </select>
              </Tooltip>

              {/* Add Tooltip to the "Rank" column in the DataGrid */}
              <div style={{ height: 400, width: '100%' }}>
                <DataGrid
                  rows={filteredRows}
                  columns={filteredColumns.map((column) => {
                    if (column.field === 'rank') {
                      return {
                        ...column,
                        renderCell: (params) => (
                          <Tooltip title={`${params.value} - ${rankDescriptions[params.value]}`} arrow>
                            <span className="tooltip">{params.value}</span>
                          </Tooltip>
                        ),
                      };
                    }

                    return column;
                  })}
                  pageSize={5}
                  checkboxSelection
                  disableSelectionOnClick
                  components={{
                    Toolbar: GridToolbar,
                  }}
                  componentsProps={{
                    toolbar: {
                      exportButton: <GridToolbarExport />,
                    },
                  }}
                />
              </div>
            </MDBox>
          </Card>
        </Grid>
      </Grid>
    </MDBox>
  </DashboardLayout>
);
}

export default SkllTables;
